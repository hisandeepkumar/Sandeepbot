import os
import logging
import requests
import json
from dotenv import load_dotenv

# 🔹 Load API Keys from .env
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")  # Get Gemini API key

# 🔹 Initialize Gemini API
API_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"

# 🔹 Logging Setup
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)

# 🔹 Bot Ka Naam
YOUR_NAME = "Sandeep"

# 🔹 Function to Detect If User Is Asking for Name
def is_asking_name(text):
    name_keywords = ["tumhara naam", "tera naam", "aap ka naam", "who are you", "your name", "whats your name"]
    return any(keyword in text.lower() for keyword in name_keywords)

# 🔹 Gemini API Call
async def chat_with_gemini(prompt):
    headers = {"Content-Type": "application/json"}
    data = {"contents": [{"parts": [{"text": prompt}]}]}

    try:
        response = requests.post(
            f"{API_ENDPOINT}?key={GEMINI_API_KEY}", headers=headers, data=json.dumps(data)
        )
        response.raise_for_status()
        response_json = response.json()

        # Extract generated text
        if 'candidates' in response_json and response_json['candidates']:
            generated_text = response_json['candidates'][0]['content']['parts'][0]['text']
            return generated_text
        elif 'generatedText' in response_json:
            return response_json.get('generatedText')
        else:
            return "Gemini API ka response unexpected format me hai."

    except requests.exceptions.RequestException as e:
        logging.error(f"Gemini API error: {e}")
        return "Gemini API se response lene me error ho gayi."

# 🔹 Function to Replace Any AI Name with Your Name
def replace_ai_name(text):
    ai_names = ["Gemini", "AI", "Artificial Intelligence", "Google", "गूगल"]
    for ai_name in ai_names:
        text = text.replace(ai_name, YOUR_NAME)
    return text